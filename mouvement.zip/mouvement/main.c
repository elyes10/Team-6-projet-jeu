#include <SDL/SDL.h>
#include <stdio.h>
#include<SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include<SDL/SDL_image.h>

int main(int argc, char *argv[])
{
    SDL_Surface *ecran = NULL, *Rebeh = NULL,*imagebackground=NULL;
    SDL_Rect positionRebeh;
    SDL_Rect positionbackground;
    positionbackground.x = 0;
    positionbackground.y = 0;
    SDL_Event event;
    int continuer = 1;

    SDL_Init(SDL_INIT_VIDEO);

    ecran = SDL_SetVideoMode(1000, 720, 32, SDL_DOUBLEBUF|SDL_HWSURFACE);
    SDL_WM_SetCaption("mouvement de rebeh", NULL);
    imagebackground = IMG_Load("background1.jpg");
    Rebeh= IMG_Load("rebeh.png");
    SDL_SetColorKey(Rebeh, SDL_TRUE, SDL_MapRGB(Rebeh->format, 0, 0, 0));

    positionRebeh.x = ecran->w / 2 - Rebeh->w / 2;
    positionRebeh.y = ecran->h / 2 - Rebeh->h / 2;

    SDL_EnableKeyRepeat(10, 10); 

    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_UP:
                        positionRebeh.y--;
                        break;

                    case SDLK_DOWN:
                        positionRebeh.y++;
                        break;
                    case SDLK_RIGHT:
                        positionRebeh.x++;
                        break;
                    case SDLK_LEFT:
                        positionRebeh.x--;
                        break;
                   case SDLK_ESCAPE: 
                   continuer = 0;
                 break;


                }
            break ;

           case SDL_MOUSEBUTTONUP:
            positionRebeh.x = event.button.x;
            positionRebeh.y = event.button.y;
            break;
                break;
        }

        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
        SDL_BlitSurface(imagebackground, NULL, ecran, &positionbackground);
        SDL_BlitSurface(Rebeh, NULL, ecran, &positionRebeh);
        SDL_Flip(ecran);
    }

    SDL_FreeSurface(Rebeh);
    SDL_FreeSurface(imagebackground);
    SDL_Quit();

    return EXIT_SUCCESS;
}
